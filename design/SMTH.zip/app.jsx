// smth — root component.
// Owns app state (artifacts, selection, unread, conn, search, undo) and the
// simulated SSE loop. Presentational pieces live in components.jsx; pure
// helpers in utils.jsx.

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ─── Tweak defaults ─────────────────────────────────────────────────────
// Marker block is parsed by the host; keep it valid JSON.
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#c96442",
  "density": "comfortable",
  "showTagline": true,
  "emptyMode": false
}/*EDITMODE-END*/;

function App() {
  const t = useTweaks(TWEAK_DEFAULTS);

  // ─── State ────────────────────────────────────────────────────────────
  const [artifacts,      setArtifacts]      = useState(() =>
    [...window.MOCK_ARTIFACTS].sort((a, b) => b.createdAt - a.createdAt)
  );
  const [hidden,         setHidden]         = useState(() => new Set());     // soft-deleted ids
  const [pendingDelete,  setPendingDelete]  = useState(null);                 // { id, title, expiresAt }
  const [selectedId,     setSelectedId]     = useState(null);
  const [unread,         setUnread]         = useState(() => new Set());
  const [conn,           setConn]           = useState('connected');
  const [query,          setQuery]          = useState('');
  const [justCopied,     setJustCopied]     = useState(false);

  const searchRef    = useRef(null);
  const undoTimerRef = useRef(null);

  const visible = useMemo(
    () => t.emptyMode ? [] : artifacts.filter(a => !hidden.has(a.id)),
    [artifacts, hidden, t.emptyMode]
  );

  // ─── URL <-> selection sync ───────────────────────────────────────────
  // First load: read ?id=, else select latest.
  useEffect(() => {
    const url = new URL(window.location.href);
    const id  = url.searchParams.get('id');
    if (id && artifacts.find(a => a.id === id)) setSelectedId(id);
    else if (visible.length > 0)                setSelectedId(visible[0].id);
  }, []); // mount only

  // Push selection to URL whenever it changes.
  useEffect(() => {
    if (!selectedId) return;
    const url = new URL(window.location.href);
    if (url.searchParams.get('id') !== selectedId) {
      url.searchParams.set('id', selectedId);
      window.history.replaceState({}, '', url);
    }
  }, [selectedId]);

  // Recover selection when the user toggles empty mode off.
  useEffect(() => {
    if (t.emptyMode) setSelectedId(null);
    else if (!selectedId && visible.length) setSelectedId(visible[0].id);
  }, [t.emptyMode]);

  // ─── Selection / unread ───────────────────────────────────────────────
  const onSelect = useCallback((id) => {
    setSelectedId(id);
    setUnread(prev => {
      if (!prev.has(id)) return prev;
      const next = new Set(prev); next.delete(id); return next;
    });
  }, []);

  // ─── Simulated SSE ─────────────────────────────────────────────────────
  // Real backend opens EventSource('/sse'); this fires the same code paths
  // (new + update + status flicker) on a deterministic timeline.
  useEffect(() => {
    if (t.emptyMode) return;
    const timers = [];

    // `new` events: queued artifacts arrive at t = delaySec.
    for (const it of window.MOCK_INCOMING) {
      timers.push(setTimeout(() => {
        const art = { ...it, createdAt: new Date() };
        setArtifacts(prev => prev.some(a => a.id === art.id) ? prev : [art, ...prev]);
        // First-load auto-select rule: only auto-switch when the main is empty.
        setSelectedId(curSel => {
          if (curSel == null) return art.id;
          setUnread(u => { const n = new Set(u); n.add(art.id); return n; });
          return curSel;
        });
      }, it.delaySec * 1000));
    }

    // `update` events: bump a recent artifact's createdAt to simulate edits.
    const updTimer = setInterval(() => {
      setArtifacts(prev => {
        if (!prev.length) return prev;
        const idx = Math.floor(Math.random() * Math.min(3, prev.length));
        const updated = { ...prev[idx], createdAt: new Date() };
        const next = [...prev]; next[idx] = updated;
        return next.sort((a, b) => b.createdAt - a.createdAt);
      });
    }, 45_000);
    timers.push(updTimer);

    // Brief status flicker so the connection pill is visible during demo.
    timers.push(setTimeout(() => setConn('reconnecting'), 14_000));
    timers.push(setTimeout(() => setConn('connected'),    16_500));

    return () => timers.forEach(x => clearTimeout(x) || clearInterval(x));
  }, [t.emptyMode]);

  // ─── Toolbar actions ──────────────────────────────────────────────────
  const selected = visible.find(a => a.id === selectedId) || null;

  const onOpen = () => selected && window.open(`/a/${selected.id}`, '_blank');

  const onCopy = () => {
    if (!selected) return;
    navigator.clipboard?.writeText(`${location.origin}/?id=${selected.id}`).catch(() => {});
    setJustCopied(true);
    setTimeout(() => setJustCopied(false), 1400);
  };

  // Soft-delete with 3s undo: hide immediately, commit on timeout.
  const onDelete = () => {
    if (!selected) return;
    const victim = selected;

    setHidden(prev => { const n = new Set(prev); n.add(victim.id); return n; });
    setSelectedId(prev => {
      const arr = visible.filter(a => a.id !== victim.id);
      const idx = visible.findIndex(a => a.id === prev);
      const next = arr[idx] || arr[idx - 1] || arr[0];
      return next ? next.id : null;
    });

    if (undoTimerRef.current) clearTimeout(undoTimerRef.current);
    setPendingDelete({
      id: victim.id,
      title: window.displayTitle(victim.title, victim.project),
      expiresAt: Date.now() + 3000,
    });
    undoTimerRef.current = setTimeout(() => {
      setArtifacts(prev => prev.filter(a => a.id !== victim.id));
      setHidden(prev => { const n = new Set(prev); n.delete(victim.id); return n; });
      setPendingDelete(null);
    }, 3000);
  };

  const onUndo = () => {
    if (!pendingDelete) return;
    if (undoTimerRef.current) clearTimeout(undoTimerRef.current);
    const id = pendingDelete.id;
    setHidden(prev => { const n = new Set(prev); n.delete(id); return n; });
    setSelectedId(id);
    setPendingDelete(null);
  };

  // ─── Keyboard shortcuts ───────────────────────────────────────────────
  // ⌘K / Ctrl-K — focus search   (works anywhere)
  // /           — focus search   (when not typing in a field)
  // Esc         — clear & blur search
  // j / k       — move selection
  // Enter       — open current in new tab
  // d           — delete current (routes through the undo flow)
  useEffect(() => {
    const onKey = (e) => {
      const tag = (document.activeElement?.tagName || '').toLowerCase();
      const inField = tag === 'input' || tag === 'textarea';

      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchRef.current?.focus();
        searchRef.current?.select();
        return;
      }

      if (inField) return;

      if (e.key === '/')      { e.preventDefault(); searchRef.current?.focus(); return; }
      if (e.key === 'Escape') { setQuery(''); searchRef.current?.blur();        return; }

      if (e.key === 'j' || e.key === 'k') {
        if (!visible.length) return;
        e.preventDefault();
        const idx = visible.findIndex(a => a.id === selectedId);
        const nextIdx = e.key === 'j'
          ? Math.min(visible.length - 1, idx + 1)
          : Math.max(0, idx - 1);
        const tgt = visible[nextIdx];
        if (!tgt) return;
        onSelect(tgt.id);
        requestAnimationFrame(() => {
          document.querySelector(`[data-aid="${tgt.id}"]`)?.scrollIntoView({ block: 'nearest' });
        });
        return;
      }

      if (e.key === 'Enter' && selectedId)  { onOpen(); return; }
      if (e.key === 'd'     && selectedId)  { e.preventDefault(); onDelete(); return; }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [visible, selectedId]);

  // ─── Render ───────────────────────────────────────────────────────────
  return (
    <div className={`app density-${t.density}`} style={{ '--accent': t.accent }}>
      <Sidebar
        artifacts={visible}
        selectedId={selectedId}
        unread={unread}
        onSelect={onSelect}
        conn={conn}
        query={query}
        setQuery={setQuery}
        searchRef={searchRef}
      />
      <MainPane
        artifact={selected}
        onOpen={onOpen}
        onCopy={onCopy}
        onDelete={onDelete}
        justCopied={justCopied}
      />

      <UndoToast pending={pendingDelete} onUndo={onUndo} />

      <TweaksPanel title="Tweaks">
        <TweakSection title="Accent">
          <TweakColor t={t} k="accent"
            options={['#c96442', '#a68a6e', '#1a1612', '#558b6e', '#7a6dba']}
            label="Color" />
        </TweakSection>
        <TweakSection title="Density">
          <TweakRadio t={t} k="density"
            options={['compact', 'comfortable']}
            label="Row density" />
        </TweakSection>
        <TweakSection title="Demo state">
          <TweakToggle t={t} k="emptyMode" label="Empty state" />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
