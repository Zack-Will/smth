// smth — presentational React components.
// All the leaf pieces (Sidebar, MainPane, EmptyState, ConnDot, UndoToast).
// State + orchestration lives in app.jsx.
//
// Helpers come from utils.jsx via globals (relTime, displayTitle, groupByDay,
// BUILD_VERSION). React hooks are pulled off `React` so this file works
// alongside the other Babel scripts without ES module plumbing.

const { useEffect, useMemo, useRef, useState } = React;

// ─── Connection-status pill ─────────────────────────────────────────────
// Green / amber / red dot + label, low-key in the sidebar header.
function ConnDot({ state }) {
  const map = {
    connected:    { color: '#558b6e', label: 'connected' },
    reconnecting: { color: '#b8860b', label: 'reconnecting' },
    disconnected: { color: '#a93226', label: 'disconnected' },
  };
  const s = map[state];
  return (
    <div className="conn">
      <span className="conn-dot" style={{
        background: s.color,
        boxShadow: state === 'connected' ? `0 0 0 2px ${s.color}22` : 'none',
        animation:  state === 'reconnecting' ? 'pulse 1.2s ease-in-out infinite' : 'none',
      }}/>
      <span>{s.label}</span>
    </div>
  );
}

// ─── Sidebar ────────────────────────────────────────────────────────────
// Brand + connection status, search box, scrollable date-grouped list,
// footer with artifact count + build version.
function Sidebar({ artifacts, selectedId, unread, onSelect, conn, query, setQuery, searchRef }) {
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return artifacts;
    return artifacts.filter(a =>
      a.title.toLowerCase().includes(q) ||
      a.project.toLowerCase().includes(q)
    );
  }, [artifacts, query]);

  const groups = useMemo(() => window.groupByDay(filtered), [filtered]);

  return (
    <aside className="sidebar">
      <div className="sb-top">
        <div className="sb-brand">
          <span className="sb-name">SMTH</span>
          <span className="sb-tag">Markdown is boring, show me the HTML</span>
        </div>
        <ConnDot state={conn} />
      </div>

      <div className="sb-search">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="7"/>
          <path d="m20 20-3.5-3.5"/>
        </svg>
        <input
          ref={searchRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search"
          spellCheck={false}
          onKeyDown={(e) => {
            if (e.key === 'Escape') { setQuery(''); e.currentTarget.blur(); }
          }}
        />
        <kbd>/</kbd>
      </div>

      <div className="sb-list">
        {groups.length === 0 && <div className="sb-empty">No matches</div>}
        {groups.map(g => (
          <div className="sb-group" key={g.label}>
            <div className="sb-group-label">{g.label}</div>
            {g.items.map(a => (
              <SidebarItem
                key={a.id}
                artifact={a}
                selected={a.id === selectedId}
                unread={unread.has(a.id)}
                onSelect={onSelect}
              />
            ))}
          </div>
        ))}
      </div>

      <div className="sb-foot">
        <span>{artifacts.length} artifacts</span>
        <span className="sb-foot-sep">·</span>
        <span title="Build version">{window.BUILD_VERSION}</span>
      </div>
    </aside>
  );
}

// One row in the sidebar list.
function SidebarItem({ artifact, selected, unread, onSelect }) {
  const a = artifact;
  return (
    <button
      data-aid={a.id}
      className={`sb-item${selected ? ' is-selected' : ''}`}
      onClick={() => onSelect(a.id)}
    >
      {selected && <span className="sb-item-bar" />}
      <div className="sb-item-row">
        <span className="sb-item-title">{a.title}</span>
        {unread && <span className="sb-item-dot" />}
      </div>
      <div className="sb-item-meta">
        <span>{a.project}</span>
        <span className="sb-item-sep">·</span>
        <span>{window.relTime(a.createdAt)}</span>
      </div>
    </button>
  );
}

// ─── Main pane ──────────────────────────────────────────────────────────
// Toolbar (title / project / time + actions) over a sandboxed iframe.
// The iframe re-srcdocs whenever the artifact id changes OR when the parent
// triggers a reload (update events from the simulated SSE).
function MainPane({ artifact, onOpen, onCopy, onDelete, justCopied }) {
  const iframeRef = useRef(null);
  const [reloadTick, setReloadTick] = useState(0);

  useEffect(() => {
    const f = iframeRef.current;
    if (!f || !artifact) return;
    f.srcdoc = artifact.html;
  }, [artifact, reloadTick]);

  // Expose reload() so the parent can ask the iframe to reload its current doc.
  useEffect(() => {
    if (!artifact) return;
    artifact._reload = () => setReloadTick(t => t + 1);
  }, [artifact]);

  if (!artifact) return <EmptyState />;

  const titleText = window.displayTitle(artifact.title, artifact.project);

  return (
    <main className="main">
      <div className="main-toolbar">
        <div className="main-toolbar-l">
          <span className="main-title" title={artifact.title}>{titleText}</span>
          <span className="main-sep">·</span>
          <span className="main-project">{artifact.project}</span>
          <span className="main-sep">·</span>
          <span className="main-time">{window.relTime(artifact.createdAt)} ago</span>
        </div>
        <div className="main-toolbar-r">
          <div className="tb-group">
            <button className="tb-btn" onClick={onCopy} title="Copy link">
              {justCopied ? <IconCheck/> : <IconLink/>}
            </button>
            <button className="tb-btn" onClick={onOpen} title="Open in new tab">
              <IconExternal/>
            </button>
          </div>
          <div className="tb-group tb-group-danger">
            <button className="tb-btn" onClick={onDelete} title="Delete  (d)">
              <IconTrash/>
            </button>
          </div>
        </div>
      </div>

      <iframe
        ref={iframeRef}
        className="main-iframe"
        sandbox="allow-scripts allow-forms allow-popups"
        title={artifact.title}
      />
    </main>
  );
}

// ─── Empty state ────────────────────────────────────────────────────────
// Shown when there are no artifacts. Hands the user a curl example so they
// can push their first one without hunting for docs.
function EmptyState() {
  const curl = `curl -X POST $SMTH_URL/api/artifacts \\
  -H "X-API-Key: $SMTH_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"html":"<h1>hello</h1>","title":"test"}'`;
  return (
    <main className="main">
      <div className="main-toolbar">
        <div className="main-toolbar-l">
          <span className="main-title" style={{ color: 'var(--fg-3)' }}>no artifact selected</span>
        </div>
      </div>
      <div className="empty">
        <div className="empty-inner">
          <div className="empty-eyebrow">smth · empty</div>
          <h1 className="empty-h">Push your first artifact.</h1>
          <p className="empty-p">Anything you POST shows up here in real time. HTML, scripts, the works — sandboxed but live.</p>
          <pre className="empty-curl">{curl}</pre>
          <div className="empty-hint">Waiting for events on <code>/sse</code>…</div>
        </div>
      </div>
    </main>
  );
}

// ─── Undo toast ─────────────────────────────────────────────────────────
// Centered bottom toast with a 3-second progress bar. Owner is responsible
// for committing the actual delete (via setTimeout) and clearing `pending`.
function UndoToast({ pending, onUndo }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!pending) return;
    const i = setInterval(() => setNow(Date.now()), 100);
    return () => clearInterval(i);
  }, [pending]);

  if (!pending) return null;
  const remaining = Math.max(0, pending.expiresAt - now);
  const pct = Math.max(0, Math.min(1, remaining / 3000));

  return (
    <div className="toast" role="status">
      <span className="toast-text">deleted “{pending.title}”</span>
      <button className="toast-btn" onClick={onUndo}>undo</button>
      <span className="toast-bar">
        <span className="toast-bar-fill" style={{ transform: `scaleX(${pct})` }}/>
      </span>
    </div>
  );
}

// ─── Icons ──────────────────────────────────────────────────────────────
// Hand-tuned 14×14 line icons; all share strokeWidth=2 and currentColor.
const iconProps = { width: 14, height: 14, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2 };
const IconCheck    = () => <svg {...iconProps}><path d="m5 12 5 5L20 7"/></svg>;
const IconLink     = () => <svg {...iconProps}><path d="M10 13a5 5 0 0 0 7.07 0l3-3a5 5 0 1 0-7.07-7.07l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.07 0l-3 3A5 5 0 1 0 11 21.07l1.5-1.5"/></svg>;
const IconExternal = () => <svg {...iconProps}><path d="M14 4h6v6"/><path d="M10 14 21 3"/><path d="M19 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h6"/></svg>;
const IconTrash    = () => <svg {...iconProps}><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>;

// Expose to other Babel script scopes.
Object.assign(window, { ConnDot, Sidebar, SidebarItem, MainPane, EmptyState, UndoToast });
