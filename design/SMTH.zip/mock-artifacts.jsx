// Mock artifact HTML payloads for the prototype.
// In production these come from the server; here we inline them so the iframe
// can srcdoc-render without a backend. Each one is a small self-contained doc.

const SHELL = (body, accent = '#3b82f6') => `<!doctype html>
<html><head><meta charset="utf-8"><style>
  :root { --accent: ${accent}; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    font: 14px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, sans-serif;
    color: #1a1612;
    background: #fdfcf8;
    padding: 32px 40px;
  }
  h1 { font-size: 20px; font-weight: 600; margin: 0 0 4px; letter-spacing: -0.01em; }
  h2 { font-size: 14px; font-weight: 600; margin: 24px 0 8px; letter-spacing: -0.005em; }
  p  { margin: 0 0 12px; color: #5a4f43; }
  .muted { color: #8a7f6e; font-size: 12px; }
  code, pre { font-family: ui-monospace, "SF Mono", Menlo, monospace; font-size: 12.5px; }
  pre { background: #f4ede0; padding: 12px 14px; border-radius: 6px; overflow: auto; }
  hr { border: 0; border-top: 0.5px solid #e6dbc5; margin: 20px 0; }
  a { color: var(--accent); text-decoration: none; }
  button { font: inherit; padding: 6px 12px; border: 0.5px solid #d8ccb1; background: #fdfcf8; border-radius: 6px; cursor: pointer; }
  button:hover { background: #f4ede0; }
  button.primary { background: var(--accent); color: #fff; border-color: var(--accent); }
  table { border-collapse: collapse; font-size: 13px; }
  td, th { padding: 6px 12px; border-bottom: 0.5px solid #efe6d2; text-align: left; }
  th { color: #5a4f43; font-weight: 500; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; }
</style></head><body>${body}</body></html>`;

const ART_DASHBOARD = SHELL(`
  <h1>Q3 Pricing Experiment — Lift Summary</h1>
  <p class="muted">Generated 2 min ago · n = 14,802 sessions</p>

  <div style="display:grid; grid-template-columns: repeat(3,1fr); gap: 12px; margin: 20px 0 28px;">
    <div style="border:0.5px solid #e5e5e5; border-radius:8px; padding:14px;">
      <div class="muted">Conversion</div>
      <div style="font-size:24px; font-weight:600; letter-spacing:-0.02em;">4.82%</div>
      <div style="color:#16a34a; font-size:12px;">+0.61 pp vs control</div>
    </div>
    <div style="border:0.5px solid #e5e5e5; border-radius:8px; padding:14px;">
      <div class="muted">ARPU</div>
      <div style="font-size:24px; font-weight:600; letter-spacing:-0.02em;">$23.40</div>
      <div style="color:#16a34a; font-size:12px;">+$1.92</div>
    </div>
    <div style="border:0.5px solid #e5e5e5; border-radius:8px; padding:14px;">
      <div class="muted">p-value</div>
      <div style="font-size:24px; font-weight:600; letter-spacing:-0.02em;">0.018</div>
      <div class="muted" style="font-size:12px;">significant</div>
    </div>
  </div>

  <h2>Funnel by variant</h2>
  <svg viewBox="0 0 600 160" width="100%" style="margin-top:8px;">
    <g font-family="ui-monospace, monospace" font-size="10" fill="#888">
      <text x="0" y="20">control</text>
      <text x="0" y="60">v_a</text>
      <text x="0" y="100">v_b</text>
      <text x="0" y="140">v_c</text>
    </g>
    <rect x="60" y="10" width="380" height="14" fill="#e5e5e5"/>
    <rect x="60" y="50" width="420" height="14" fill="#e5e5e5"/>
    <rect x="60" y="90" width="460" height="14" fill="var(--accent)"/>
    <rect x="60" y="130" width="395" height="14" fill="#e5e5e5"/>
  </svg>

  <p class="muted" style="margin-top:24px;">v_b ships Friday pending eng review.</p>
`);

const ART_CALC = SHELL(`
  <h1>Mortgage check</h1>
  <p class="muted">Quick affordability calc — drag the sliders.</p>
  <div style="display:grid; grid-template-columns: 120px 1fr 80px; gap: 14px 16px; align-items:center; margin-top:20px;">
    <label>Principal</label>
    <input type="range" id="p" min="100000" max="2000000" step="10000" value="650000" style="accent-color: var(--accent);">
    <span id="pv" style="font-variant-numeric: tabular-nums;">$650,000</span>

    <label>Rate</label>
    <input type="range" id="r" min="3" max="9" step="0.05" value="6.4" style="accent-color: var(--accent);">
    <span id="rv" style="font-variant-numeric: tabular-nums;">6.40%</span>

    <label>Term</label>
    <input type="range" id="t" min="10" max="30" step="5" value="30" style="accent-color: var(--accent);">
    <span id="tv" style="font-variant-numeric: tabular-nums;">30 yr</span>
  </div>
  <hr>
  <div style="display:flex; gap: 32px; align-items: baseline;">
    <div>
      <div class="muted">Monthly</div>
      <div id="m" style="font-size:28px; font-weight:600; letter-spacing:-0.02em; font-variant-numeric: tabular-nums;">$4,068</div>
    </div>
    <div>
      <div class="muted">Total interest</div>
      <div id="ti" style="font-size:28px; font-weight:600; letter-spacing:-0.02em; font-variant-numeric: tabular-nums;">$814,615</div>
    </div>
  </div>
  <script>
    const fmt = n => '$' + Math.round(n).toLocaleString();
    function calc() {
      const p = +document.getElementById('p').value;
      const r = +document.getElementById('r').value / 100 / 12;
      const n = +document.getElementById('t').value * 12;
      const m = p * r / (1 - Math.pow(1 + r, -n));
      document.getElementById('pv').textContent = fmt(p);
      document.getElementById('rv').textContent = (+document.getElementById('r').value).toFixed(2) + '%';
      document.getElementById('tv').textContent = (n/12) + ' yr';
      document.getElementById('m').textContent = fmt(m);
      document.getElementById('ti').textContent = fmt(m * n - p);
    }
    document.querySelectorAll('input').forEach(i => i.addEventListener('input', calc));
    calc();
  </script>
`);

const ART_DIFF = SHELL(`
  <h1>auth_middleware.py</h1>
  <p class="muted">3 changes · suggested by review</p>
  <pre style="line-height:1.7; padding: 0; background: transparent; border:0.5px solid #e5e5e5; border-radius:6px; overflow: hidden;"><div style="padding: 4px 14px; background:#f6f6f6; color:#666; font-size:11px; border-bottom:0.5px solid #e5e5e5;">@@ -42,9 +42,11 @@ def verify_token(req):</div><div style="padding: 0 14px;">
<span style="color:#888;">    headers = req.headers</span>
<span style="color:#888;">    token = headers.get("Authorization", "")</span>
<span style="background:#fef2f2; color:#991b1b; display:block; margin: 0 -14px; padding: 0 14px;">-   if not token:</span>
<span style="background:#fef2f2; color:#991b1b; display:block; margin: 0 -14px; padding: 0 14px;">-       return None</span>
<span style="background:#f0fdf4; color:#166534; display:block; margin: 0 -14px; padding: 0 14px;">+   if not token or not token.startswith("Bearer "):</span>
<span style="background:#f0fdf4; color:#166534; display:block; margin: 0 -14px; padding: 0 14px;">+       raise AuthError("missing bearer token")</span>
<span style="background:#f0fdf4; color:#166534; display:block; margin: 0 -14px; padding: 0 14px;">+   token = token.removeprefix("Bearer ").strip()</span>
<span style="color:#888;">    try:</span>
<span style="color:#888;">        return jwt.decode(token, KEY, algorithms=["HS256"])</span>
<span style="background:#fef2f2; color:#991b1b; display:block; margin: 0 -14px; padding: 0 14px;">-   except jwt.InvalidTokenError:</span>
<span style="background:#f0fdf4; color:#166534; display:block; margin: 0 -14px; padding: 0 14px;">+   except jwt.InvalidTokenError as e:</span>
<span style="background:#f0fdf4; color:#166534; display:block; margin: 0 -14px; padding: 0 14px;">+       log.warning("invalid token: %s", e)</span>
<span style="color:#888;">        return None</span>
</div></pre>
  <div style="display:flex; gap:8px; margin-top:16px;">
    <button class="primary">Apply</button>
    <button>Open in editor</button>
  </div>
`);

const ART_PALETTE = SHELL(`
  <h1>Palette — "deep field"</h1>
  <p class="muted">Hue ramp at L=70, C=0.12 oklch</p>
  <div style="display:grid; grid-template-columns: repeat(8, 1fr); gap: 8px; margin-top: 20px;">
    ${[0,45,90,135,180,225,270,315].map(h => `
      <div>
        <div style="background: oklch(0.7 0.12 ${h}); aspect-ratio: 1/1.2; border-radius: 6px; border: 0.5px solid #e5e5e5;"></div>
        <div style="font-family: ui-monospace, monospace; font-size: 10px; color:#666; margin-top: 6px;">h ${h}</div>
      </div>
    `).join('')}
  </div>
  <h2>Neutrals</h2>
  <div style="display:flex; gap: 0; border-radius: 6px; overflow: hidden; border: 0.5px solid #e5e5e5;">
    ${[0.98,0.94,0.88,0.78,0.62,0.45,0.28,0.16].map(l => `
      <div style="background: oklch(${l} 0.005 240); flex:1; height: 56px;"></div>
    `).join('')}
  </div>
`);

const ART_TODO = SHELL(`
  <h1>Today</h1>
  <p class="muted">5 items · 2 done</p>
  <div id="list" style="margin-top: 16px;"></div>
  <script>
    const items = [
      {t: 'Reply to David re: API contract', d: true},
      {t: 'Review v_b experiment ramp plan', d: true},
      {t: 'Draft Q3 OKR doc', d: false},
      {t: 'Send invoice — Acme', d: false},
      {t: 'Workout @ 6pm', d: false},
    ];
    const root = document.getElementById('list');
    items.forEach((it, i) => {
      const row = document.createElement('label');
      row.style.cssText = 'display:flex; align-items:center; gap:10px; padding:8px 0; border-bottom:0.5px solid #eee; cursor:pointer;';
      row.innerHTML = '<input type="checkbox" ' + (it.d ? 'checked' : '') + ' style="accent-color: var(--accent);"><span style="' + (it.d ? 'color:#999; text-decoration:line-through;' : '') + '">' + it.t + '</span>';
      root.appendChild(row);
      row.querySelector('input').addEventListener('change', e => {
        row.querySelector('span').style.cssText = e.target.checked ? 'color:#999; text-decoration:line-through;' : '';
      });
    });
  </script>
`);

const ART_RECEIPT = SHELL(`
  <h1>Receipt — Whole Foods</h1>
  <p class="muted">May 9, 2026 · 4:12 PM · Visa ••3301</p>
  <table style="width:100%; margin-top:16px;">
    <tr><td>Organic strawberries</td><td style="text-align:right; font-variant-numeric: tabular-nums;">$6.99</td></tr>
    <tr><td>Sourdough loaf</td><td style="text-align:right; font-variant-numeric: tabular-nums;">$5.49</td></tr>
    <tr><td>Bel Gioioso burrata 8oz</td><td style="text-align:right; font-variant-numeric: tabular-nums;">$8.99</td></tr>
    <tr><td>Heirloom tomatoes (1.2 lb)</td><td style="text-align:right; font-variant-numeric: tabular-nums;">$5.39</td></tr>
    <tr><td>Olive oil — Frantoio</td><td style="text-align:right; font-variant-numeric: tabular-nums;">$18.99</td></tr>
    <tr><td>La Croix grapefruit 8pk</td><td style="text-align:right; font-variant-numeric: tabular-nums;">$4.49</td></tr>
    <tr><td colspan="2" style="padding:0; height:6px;"></td></tr>
    <tr><th>Subtotal</th><th style="text-align:right; font-variant-numeric: tabular-nums;">$50.34</th></tr>
    <tr><td>Tax</td><td style="text-align:right; font-variant-numeric: tabular-nums;">$0.41</td></tr>
    <tr><td style="font-weight:600;">Total</td><td style="text-align:right; font-weight:600; font-variant-numeric: tabular-nums;">$50.75</td></tr>
  </table>
`);

const ART_CHART = SHELL(`
  <h1>Latency — last 24h</h1>
  <p class="muted">api.smth.app · p50 / p95 / p99</p>
  <svg viewBox="0 0 720 240" width="100%" style="margin-top:20px;">
    <defs>
      <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0" stop-color="var(--accent)" stop-opacity="0.18"/>
        <stop offset="1" stop-color="var(--accent)" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <g stroke="#eee" stroke-width="0.5">
      <line x1="0" x2="720" y1="60"  y2="60"/>
      <line x1="0" x2="720" y1="120" y2="120"/>
      <line x1="0" x2="720" y1="180" y2="180"/>
    </g>
    <path d="M0,180 ${Array.from({length:48},(_,i)=>{const x=i/47*720;const y=120+Math.sin(i*0.4)*30+Math.sin(i*0.13)*22;return 'L'+x.toFixed(1)+','+y.toFixed(1);}).join(' ')} L720,240 L0,240 Z" fill="url(#g)"/>
    <path d="M0,180 ${Array.from({length:48},(_,i)=>{const x=i/47*720;const y=120+Math.sin(i*0.4)*30+Math.sin(i*0.13)*22;return 'L'+x.toFixed(1)+','+y.toFixed(1);}).join(' ')}" fill="none" stroke="var(--accent)" stroke-width="1.5"/>
    <path d="M0,200 ${Array.from({length:48},(_,i)=>{const x=i/47*720;const y=170+Math.sin(i*0.3+1)*12+Math.sin(i*0.18)*8;return 'L'+x.toFixed(1)+','+y.toFixed(1);}).join(' ')}" fill="none" stroke="#9ca3af" stroke-width="1"/>
    <g font-family="ui-monospace, monospace" font-size="9" fill="#888">
      <text x="722" y="63">800ms</text>
      <text x="722" y="123">400ms</text>
      <text x="722" y="183">100ms</text>
    </g>
  </svg>
  <div style="display:flex; gap:24px; font-size:12px; color:#666; margin-top: 8px;">
    <span><span style="display:inline-block;width:10px;height:2px;background:var(--accent);vertical-align:middle;"></span> p95</span>
    <span><span style="display:inline-block;width:10px;height:2px;background:#9ca3af;vertical-align:middle;"></span> p50</span>
  </div>
`);

const ART_QUOTE = SHELL(`
  <div style="max-width: 520px;">
    <h1 style="font-size: 28px; line-height: 1.25; letter-spacing: -0.015em;">A program is composed of small, simple parts. The discipline is in keeping them small and simple.</h1>
    <p class="muted" style="margin-top: 16px;">— from "Notes on engineering practice", saved earlier</p>
    <div style="display:flex; gap:8px; margin-top: 24px;">
      <button>Save quote</button>
      <button>Find source</button>
    </div>
  </div>
`);

const ART_MEETING = SHELL(`
  <h1>Sync — Platform / Growth</h1>
  <p class="muted">Wed May 7 · 30 min · 4 attendees</p>

  <h2>Decisions</h2>
  <ul style="padding-left: 18px; color:#444;">
    <li>Migrate edge cache to Fastly by end of month — owner: <b>Priya</b></li>
    <li>Drop legacy /v1/sessions endpoint after June 1 deprecation window</li>
    <li>v_b pricing experiment: ship to 50% on Friday</li>
  </ul>

  <h2>Open questions</h2>
  <ul style="padding-left: 18px; color:#444;">
    <li>Do we keep the websocket fallback for safari &lt; 16?</li>
    <li>Who owns the post-mortem writeup for the May 3 incident?</li>
  </ul>

  <h2>Action items</h2>
  <table style="width:100%; margin-top:8px;">
    <tr><th>Who</th><th>What</th><th>By</th></tr>
    <tr><td>D. Chen</td><td>Draft RFC for new ratelimiter</td><td>May 14</td></tr>
    <tr><td>Priya</td><td>Fastly migration plan</td><td>May 12</td></tr>
    <tr><td>Marcus</td><td>v_b ramp readiness review</td><td>May 9</td></tr>
  </table>
`);

const ART_LOADING = SHELL(`
  <h1>Building report…</h1>
  <p class="muted">Pulling from BigQuery · ~30s</p>
  <div style="display:flex; flex-direction:column; gap:12px; margin-top:20px; max-width: 420px;">
    <div style="display:flex; align-items:center; gap:10px;"><span style="color:#16a34a;">✓</span><span>Authenticated</span></div>
    <div style="display:flex; align-items:center; gap:10px;"><span style="color:#16a34a;">✓</span><span>Query plan compiled</span></div>
    <div style="display:flex; align-items:center; gap:10px;"><span style="color:#16a34a;">✓</span><span>Scanned 4.2 TB</span></div>
    <div style="display:flex; align-items:center; gap:10px;"><span class="spin" style="display:inline-block;width:12px;height:12px;border:1.5px solid #e5e5e5;border-top-color:var(--accent);border-radius:50%;animation:s 0.8s linear infinite;"></span><span>Aggregating by cohort</span></div>
    <div style="display:flex; align-items:center; gap:10px; color:#bbb;"><span>○</span><span>Render charts</span></div>
  </div>
  <style>@keyframes s { to { transform: rotate(360deg); } }</style>
`);

// Each artifact: id, title, project, createdAt (Date), updatedAt, html.
// We use real Date objects so grouping ("Today", "Yesterday", absolute date) works.
const now = new Date('2026-05-10T14:30:00');
const minutesAgo = (m) => new Date(now.getTime() - m * 60_000);
const daysAgo    = (d, h=10) => { const x = new Date(now); x.setDate(x.getDate()-d); x.setHours(h,15,0,0); return x; };

window.MOCK_ARTIFACTS = [
  { id: '01HXY9Z000001', title: 'Q3 pricing experiment — lift summary', project: 'growth',  createdAt: minutesAgo(2),   html: ART_DASHBOARD },
  { id: '01HXY9Z000002', title: 'Mortgage affordability check',          project: 'personal', createdAt: minutesAgo(34),  html: ART_CALC },
  { id: '01HXY9Z000003', title: 'auth_middleware.py — review patch',     project: 'platform', createdAt: minutesAgo(91),  html: ART_DIFF },
  { id: '01HXY9Z000004', title: 'Palette — "deep field"',                project: 'design',   createdAt: minutesAgo(220), html: ART_PALETTE },
  { id: '01HXY9Z000005', title: 'Today',                                 project: 'personal', createdAt: minutesAgo(380), html: ART_TODO },

  { id: '01HXY9Z000006', title: 'Latency — last 24h',                    project: 'platform', createdAt: daysAgo(1, 22),  html: ART_CHART },
  { id: '01HXY9Z000007', title: 'Sync — Platform / Growth',              project: 'meetings', createdAt: daysAgo(1, 14),  html: ART_MEETING },
  { id: '01HXY9Z000008', title: 'Receipt — Whole Foods',                 project: 'personal', createdAt: daysAgo(1, 16),  html: ART_RECEIPT },
  { id: '01HXY9Z000009', title: 'Notes on engineering practice',         project: 'reading',  createdAt: daysAgo(1, 9),   html: ART_QUOTE },

  { id: '01HXY9Z00000A', title: 'Cohort report — building',              project: 'growth',   createdAt: daysAgo(2, 11),  html: ART_LOADING },
  { id: '01HXY9Z00000B', title: 'Onboarding funnel — week 18',           project: 'growth',   createdAt: daysAgo(2, 9),   html: ART_DASHBOARD },
  { id: '01HXY9Z00000C', title: 'Mortgage affordability check',          project: 'personal', createdAt: daysAgo(3, 20),  html: ART_CALC },
  { id: '01HXY9Z00000D', title: 'Color study — neutrals at 0.005C',      project: 'design',   createdAt: daysAgo(4, 15),  html: ART_PALETTE },
  { id: '01HXY9Z00000E', title: 'API rate-limit RFC — first pass',       project: 'platform', createdAt: daysAgo(5, 10),  html: ART_DIFF },
  { id: '01HXY9Z00000F', title: 'Grocery receipt — May 4',               project: 'personal', createdAt: daysAgo(6, 17),  html: ART_RECEIPT },
  { id: '01HXY9Z00000G', title: 'Standup notes — Mon',                   project: 'meetings', createdAt: daysAgo(7, 9),   html: ART_MEETING },
  { id: '01HXY9Z00000H', title: 'Quote — practice notes',                project: 'reading',  createdAt: daysAgo(9, 21),  html: ART_QUOTE },
];

// New artifacts that the simulated SSE will push in over time.
window.MOCK_INCOMING = [
  { id: '01HXY9Z00010A', title: 'Incident timeline — db-2 failover',     project: 'platform', html: ART_LOADING,   delaySec: 8 },
  { id: '01HXY9Z00010B', title: 'Weekly retro',                         project: 'design',   html: ART_MEETING,   delaySec: 22 },
  { id: '01HXY9Z00010C', title: 'Spotify wrapped — May edition',         project: 'personal', html: ART_QUOTE,     delaySec: 38 },
];
