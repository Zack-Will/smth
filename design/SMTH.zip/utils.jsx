// smth — pure helpers shared by the React layer.
// No JSX, no React, no DOM — just date / string utilities and constants.

// Today, frozen for the prototype so all relative-time labels stay stable.
// Replace with `new Date()` once we wire up the real backend.
window.TODAY_REF = new Date('2026-05-10T14:30:00');

// Build version. Real deploy injects via window.__SMTH_VERSION__; the fallback
// is just so the prototype has something concrete to show.
window.BUILD_VERSION = window.__SMTH_VERSION__ || 'v0.1.2-rc4';

// True if `a` and `b` fall on the same calendar day.
window.isSameDay = function isSameDay(a, b) {
  return a.getFullYear() === b.getFullYear()
      && a.getMonth()    === b.getMonth()
      && a.getDate()     === b.getDate();
};

// Sidebar grouping label for a date: Today / Yesterday / "May 8" / "May 8, 2025".
window.dayBucket = function dayBucket(d) {
  const today = window.TODAY_REF;
  if (window.isSameDay(d, today)) return 'Today';
  const y = new Date(today); y.setDate(y.getDate() - 1);
  if (window.isSameDay(d, y)) return 'Yesterday';
  const sameYear = d.getFullYear() === today.getFullYear();
  return d.toLocaleDateString(
    'en-US',
    sameYear
      ? { month: 'short', day: 'numeric' }
      : { month: 'short', day: 'numeric', year: 'numeric' }
  );
};

// Compact relative-time string: "12s", "4m", "3h", or absolute clock for older.
window.relTime = function relTime(d) {
  const s = Math.max(1, Math.floor((window.TODAY_REF - d) / 1000));
  if (s <    60) return s + 's';
  if (s <  3600) return Math.floor(s /   60) + 'm';
  if (s < 86400) return Math.floor(s / 3600) + 'h';
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
};

// Walk an artifact list (already date-sorted desc) into [{label, items}].
window.groupByDay = function groupByDay(arts) {
  const groups = [];
  let last = null;
  for (const a of arts) {
    const b = window.dayBucket(a.createdAt);
    if (b !== last) { groups.push({ label: b, items: [] }); last = b; }
    groups[groups.length - 1].items.push(a);
  }
  return groups;
};

// If a title trails with "— {project}" (or hyphen / en-dash variants), strip
// it so the toolbar doesn't render "design · design".
window.displayTitle = function displayTitle(title, project) {
  if (!project) return title;
  const safe = project.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re   = new RegExp('\\s*[—\\-–]\\s*' + safe + '\\s*$', 'i');
  return title.replace(re, '').trim() || title;
};
